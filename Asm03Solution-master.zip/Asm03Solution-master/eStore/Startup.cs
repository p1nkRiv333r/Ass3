﻿namespace eStore
{
    public class Startup
    {
    }
}
